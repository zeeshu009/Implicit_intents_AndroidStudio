package com.mistercoding.implicitintent

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnCall  = findViewById<Button>(R.id.btnCall);
        val btnGallery = findViewById<Button>(R.id.btnCamera);
        val btnGitHub = findViewById<Button>(R.id.btnWeb);
        val btnShare = findViewById<Button>(R.id.btnShare);

        // open Android Call
        btnCall.setOnClickListener(){

            val intent = Intent(Intent.ACTION_DIAL);
            startActivity(intent);
        }
        //Open Android Camera
        btnGallery.setOnClickListener(){
            val intent = Intent(MediaStore.ACTION_PICK_IMAGES);
            startActivity(intent);
        }
        // Open my github
        btnGitHub.setOnClickListener(){
           val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("https://www.google.com/");
            startActivity(intent);
        }
        // Open share like emails
        btnShare.setOnClickListener(){
            val textMessage = "Hello"
          val sendIntent =  Intent().apply {
              action = Intent.ACTION_SEND
              putExtra(Intent.EXTRA_TEXT, textMessage)
              type = "text/plan"
          }
            try {
                startActivity(sendIntent);
            }catch (e:ActivityNotFoundException){
                println(e);
            }

        }
    }
}